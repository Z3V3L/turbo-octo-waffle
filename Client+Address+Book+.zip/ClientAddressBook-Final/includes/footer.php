        </div><!-- end .container -->

        <footer class="text-center">
            <hr>
            <small>Coded with &hearts; by <a href="http://bradhussey.ca/">Brad</a> in YYC</small>
        </footer>
        
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
        
        <!-- Bootstrap JS -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    </body>
</html>